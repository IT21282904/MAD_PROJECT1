package com.example.mad_project

data class LocationDat(val lc: String,val ds: String,val mp: String,val fp:String)
