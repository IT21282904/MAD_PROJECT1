package com.example.mad_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Driver_select : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_driver_select)
    }
}